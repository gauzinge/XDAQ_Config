package rcms.fsm.common;

import rcms.statemachine.definition.Input;

/**
 * @author Samim Erhan
 * 
 * Defines the Inputs (Commands) for the XDAQ Applications
 * 
 */
public class EVBInputs {

	public static final Input CONFIGURE   = new Input("Configure");
	public static final Input ENABLE = new Input("Enable");
	public static final Input SUSPEND     = new Input("Suspend");
	public static final Input RESUME   = new Input("Resume");
	public static final Input HALT        = new Input("Halt");
}
