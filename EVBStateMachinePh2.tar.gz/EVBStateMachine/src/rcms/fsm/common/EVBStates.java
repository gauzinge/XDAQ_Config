package rcms.fsm.common;

import rcms.statemachine.definition.State;

/**
 * @author S. Erhan
 * 
 * it defines the XDAQ EVB states.
 */
public final class EVBStates {
	public static final State READY = new State("Ready");

	public static final State ENABLED = new State("Enabled");

	public static final State SUSPENDED = new State("Suspended");

	public static final State HALTED = new State("Halted");

	public static final State FAILED = new State("failed");
}