package rcms.fsm.tkfsm;

import rcms.statemachine.definition.State;

/**
 * @author Samim Erhan
 * 
 * Defines the States of a detector Function Mananger State Machine example
 */
public final class States {
	public static final State CREATED = new State("Created");
	public static final State PREPARED = new State("Prepared");
	public static final State INITIAL = new State("Initial");
	public static final State HALTED = new State("Halted");
	public static final State THALTED = new State("halted");
	public static final State HALTING = new State("halting");
	public static final State STOPPING = new State("stopping");
	public static final State PREHALTED = new State("PreHalted");
	public static final State PRESTOPPED = new State("PreStopped");
	public static final State CONFIGURED = new State( "Configured" );
	public static final State TCONFIGURED = new State( "configured" );
	public static final State DCUCONFIGURED = new State( "DCUConfigured" );
	public static final State PRECONFIGURED = new State( "PreConfigured" );
	public static final State ENABLED = new State("Enabled");
	public static final State TENABLED = new State("enabled");
	public static final State ERROR = new State("Error");
}
