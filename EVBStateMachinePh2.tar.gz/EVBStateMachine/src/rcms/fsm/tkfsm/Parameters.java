package rcms.fsm.tkfsm;


import rcms.fm.fw.parameter.ParameterSet;
import rcms.fm.fw.parameter.type.StringT;
import rcms.fm.fw.parameter.type.IntegerT;
import rcms.fm.fw.parameter.FunctionManagerParameter;

public class Parameters {
	public static final String FED_REINIT = "FED_REINIT";
	public static final String FED_FASTINIT = "FED_FASTINIT";
	public static final String RUN_NUMBER = "RUN_NUMBER";
	public static final String RUN_TYPE = "RUN_TYPE";
	public static final String ERROR = "ERROR";
	public static final String NRU = "NRU";
	public static final String FED_MASK = "FED_MASK";
	public static final ParameterSet LVL_ONE_PARAMETER_SET = new ParameterSet();
	static {
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<StringT>(RUN_NUMBER,  new StringT("")));
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<StringT>(RUN_TYPE,  new StringT("boh")));
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<StringT>(FED_REINIT,  new StringT("boh")));
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<StringT>(FED_FASTINIT,  new StringT("boh")));
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<StringT>(ERROR,  new StringT("OK")));
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<IntegerT>(NRU,  new IntegerT(0)));
		LVL_ONE_PARAMETER_SET.put(new FunctionManagerParameter<StringT>(FED_MASK,  new StringT("")));
	}

}
