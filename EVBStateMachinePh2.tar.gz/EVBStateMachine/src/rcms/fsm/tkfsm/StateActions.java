package rcms.fsm.tkfsm;

import org.apache.log4j.Logger;

import rcms.fm.fw.user.UserActionException;
import rcms.fm.fw.user.UserActions;

/**
 * @author Samim Erhan
 * 
 * State Action class for the Detector Top Function Manager.
 *  
 */
public class StateActions extends UserActions {
	static Logger logger = Logger.getLogger(StateActions.class);

	String debugFlag = "true";
	

	public void InitialEntryAction() throws UserActionException {
		logger.info("Initial state entry action");

	}

	public void InitialExitAction() throws UserActionException {
		logger.info("Initial state exit action");

	}

	public void PreConfiguredEntryAction() throws UserActionException {
		logger.info("PreConfigured state entry action");

	}

	public void PreConfiguredExitAction() throws UserActionException {
		logger.info("PreConfigured state exit action");

	}

	public void PreStoppedEntryAction() throws UserActionException {
		logger.info("PreStopped state entry action");

	}
	public void PreStoppedExitAction() throws UserActionException {
		logger.info("PreStopped state exit action");

	}

	public void DcuConfiguredEntryAction() throws UserActionException {
		logger.info("DcuConfigured state entry action");

	}

	public void DcuConfiguredExitAction() throws UserActionException {
		logger.info("DcuConfigured state exit action");

	}
	public void ConfiguredEntryAction() throws UserActionException {
		logger.info("Configured state entry action");

	}

	public void ConfiguredExitAction() throws UserActionException {
		logger.info("Configured state exit action");

	}


	public void HaltedEntryAction() throws UserActionException {
		logger.info("RunPaused state entry action");

	}

	public void HaltedExitAction() throws UserActionException {
		logger.info("RunPaused state exit action");

	}
	public void PreHaltedEntryAction() throws UserActionException {
		logger.info("PreHalted state entry action");

	}

	public void PreHaltedExitAction() throws UserActionException {
		logger.info("PreHalted state exit action");

	}

	public void EnabledEntryAction() throws UserActionException {
		logger.info("Enabled state entry action");

	}

	public void EnabledExitAction() throws UserActionException {
		logger.info("Enabled state exit action");

	}


	public void ErrorEntryAction() throws UserActionException {
		logger.info("Error state entry action");

	}

	public void ErrorExitAction() throws UserActionException {
		logger.info("Error state exit action");

	}

}
