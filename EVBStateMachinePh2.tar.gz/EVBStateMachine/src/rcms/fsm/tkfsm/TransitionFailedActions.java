package rcms.fsm.tkfsm;

import org.apache.log4j.Logger;

import rcms.fm.fw.user.UserActionException;
import rcms.fm.fw.user.UserActions;
import rcms.statemachine.StateMachineException;

/**
 * @author S. Erhan
 * 
 * Failed Transitions Action class for an example detector Function Manager
 *  
 */
public class TransitionFailedActions extends UserActions {
	static Logger logger = Logger.getLogger(TransitionFailedActions.class);

	//private QualifiedGroup qualifiedGroup = null;


	private void fireError() throws UserActionException {
		logger.error("Firing a SETERROR");
		getUserFunctionManager().fireEvent(Inputs.SETERROR);
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void initializeFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing initializeFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void initialiseFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing initialiseFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void restartFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing restartFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void preconfigureFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing preconfigureFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void configureDcuFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing configureDcuFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void configureFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing configureFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void enableFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing enableFailedAction";
		logger.info(infoMess);
		fireError();
	}
	/**
	 * 
	 * @throws UserActionException
	 */
	public void haltFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing haltFailedAction";
		logger.info(infoMess);
		fireError();
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void haltDcuFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing haltDcuFailedAction";
		logger.info(infoMess);
		fireError();
	}

	public void prehaltFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing prehaltFailedAction";
		logger.info(infoMess);
		fireError();
	}
	public void stopFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing stopFailedAction";
		logger.info(infoMess);
		fireError();
	}
	public void prestopFailedAction() throws UserActionException {
		String infoMess = "Detector: Executing prestopFailedAction";
		logger.info(infoMess);
		fireError();
	}

	public void setErrorFailedAction() throws UserActionException {
		String errorMsg = "Executing setErrorFailedAction";
		logger.info(errorMsg);
		throw new UserActionException(errorMsg);
	}

	public void resetFailedAction() throws UserActionException {
		String errorMsg = "Executing resetFailedAction";
		logger.info(errorMsg);
		throw new UserActionException(errorMsg);
	}

	public void coldresetFailedAction() throws UserActionException {
		String errorMsg = "Executing coldresetFailedAction";
		logger.info(errorMsg);
		throw new UserActionException(errorMsg);
	}

}
