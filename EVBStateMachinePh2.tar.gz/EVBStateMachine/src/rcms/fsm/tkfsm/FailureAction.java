package rcms.fsm.tkfsm;

import rcms.statemachine.StateMachineException;
import rcms.statemachine.TransitionFailureEvent;
import rcms.statemachine.TransitionFailureListener;

/**
 * @author Samim Erhan
 * 
 * TransitionFailed Events class for an example detector Function manager
 */
public class FailureAction implements TransitionFailureListener {
	public FailureAction() {
	}

	// TransitionFailedListener implementation
	public void transitionFailureOccurred(TransitionFailureEvent evt) {
		StateMachine stateMachine = (StateMachine) evt.getSource();
		try {
			stateMachine.setState(States.ERROR);
		} catch (StateMachineException e) {
			e.printStackTrace();
			return;
		}
	}

}
