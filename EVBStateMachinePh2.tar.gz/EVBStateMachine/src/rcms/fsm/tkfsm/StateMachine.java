package rcms.fsm.tkfsm;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import rcms.fm.fw.user.UserActionException;
import rcms.fm.fw.user.UserFunctionManager;
import rcms.fm.resource.qualifiedresource.FunctionManager;
import rcms.fm.resource.qualifiedresource.XdaqExecutive;
import rcms.fm.resource.qualifiedresource.JobControl;
import rcms.statemachine.definition.State;
import rcms.statemachine.definition.StateMachineDefinitionException;
import rcms.fm.fw.parameter.ParameterSet;
import rcms.fm.fw.parameter.CommandParameter;


/**
 * @author Samim Erhan
 * 
 * User State Machine for controlling an example detetor Function Manager.
 *  
 */
public class StateMachine extends UserFunctionManager {
    static Logger logger = Logger.getLogger(StateMachine.class);
    
	// Transition Actions
    private TransitionActions transitionActions = null;//new TransitionActions();

	// Getting the list of XDaqApplications to control
	private List listXdaqApps = null;

        
	/**
	 * Default Constructor. Here the Finite State Machine must be defined.
	 * 
	 * @throws StateMachineDefinitionException
	 */
	public void init() throws StateMachineDefinitionException {
		//
		// Any State Machine Implementation must provide the framework
		// with some information about itself.
		//

		//
		// Set first of all the State Machine Definition
		//
                parameterSet = Parameters.LVL_ONE_PARAMETER_SET;
		StateMachineDefinition fsmdef = new StateMachineDefinition();
		setStateMachineDefinition(fsmdef);


		// Add a TransitionFailureListener
		addTransitionFailureListener(new FailureAction());

		// Add a StateChangedListener
		addStateChangedListener(new StateChangedAction());

		transitionActions = (TransitionActions)fsmdef.getTransitionActions();

	}

	public State getUpdatedState() {
		return this.getState();
	}

	public void createAction(ParameterSet<CommandParameter> parameters) throws UserActionException {
	    // int sleeptime=5;
		//
		// Some Initialization code can be put here
		//
		logger.info("Detector StateMachine createAction");
		/*
		    logger.info("Sleeping "+sleeptime+" sec ...");
		    try {
			Thread.sleep(sleeptime*1000);
		    } catch (InterruptedException e){
			e.printStackTrace();
			throw new  UserActionException("Thread sleep failed while waiting "+sleeptime+" sec");
		    }
		*/
		/*
		try {

			transitionActions.initializeAction();
		} catch (UserActionException e) {
			destroyAction();
			throw e;
		}
		*/
	}

	public void destroyAction() throws UserActionException {
	    Iterator it;
		//
		// kill everything
		//
	    /* this is the old way using killAll 

		// get job controls
		List listJC = qualifiedGroup
				.seekQualifiedResourcesOfType(new JobControl());
		JobControl jc = null;
		it = listJC.iterator();
		while (it.hasNext()) {
			jc = (JobControl) it.next();
			logger.info("killAll() called on " + jc.getResource().getURL());
			jc.killAll();
		}
	    */
	    // This is the new way
	    logger.info ("Destroy Action: before destroyXDAQ");
	    destroyXDAQ();
	    logger.info ("Destroy Action: after destroyXDAQ");
		// retrieve the Function Managers in this Group
		List listFMChildren = qualifiedGroup
				.seekQualifiedResourcesOfType(new FunctionManager());
		FunctionManager fmChild = null;
		it = listFMChildren.iterator();
		while (it.hasNext()) {
			fmChild = (FunctionManager) it.next();
			logger
					.info("Destroy() called on "
							+ fmChild.getResource().getURL());
			try {
				fmChild.destroy();
			} catch (Exception e) {
				logger.error("Could not destroy fm-client, exception:"
						+ e.getMessage());
				throw new UserActionException(
						"Could not destroy fm-client, exception:"
								+ e.getMessage());
			}
		}
	}

	public void destroyXDAQ() throws UserActionException {
		XdaqExecutive ex = null;
		JobControl jc = null;
		// get executives and their job controls 
		List listExecutive = qualifiedGroup
				.seekQualifiedResourcesOfType(new XdaqExecutive());
		
    		Iterator it = listExecutive.iterator();
                while (it.hasNext()) {
		    ex = (XdaqExecutive)it.next();
			    /*
			jc = ex.getMyJobControl();
			if(jc == null) {
				logger.error("There is no JC for " + ex.getResource().getURL());
				return;
			}
                       if(jc.isInitialized()) {
                                logger.debug("killJid() called on " + jc.getResource().getURL() + " for Id " + ex.jobIdentifier + " Registry " + qualifiedGroup.getRegistryEntry( ex.jobIdentifier ) );
                                try {                
                                   jc.killJid(qualifiedGroup.getRegistryEntry( ex.jobIdentifier ) );

                                } catch (Exception e) {
                                        logger.error("Failed to kill " + ex.getResource().getURL() + "\n" ,e);  
				} 
                       }
			    */
			    ex.killMe();
		}
	}


	//
	// User Defined Methods
	//
	/*
	 * public void defineConditionState() { // Retrieve and check the current
	 * qualified group
	 * 
	 * QualifiedGroup qg = getQualifiedGroup();
	 * 
	 * if( qg == null ) return; // get the xdaq-apps // make a prototype to
	 * retrieve the apps XdaqApplication xdaqAppsProto = new XdaqApplication(); //
	 * retrieve the apps List listXdaqApps = qg.seekQualifiedResourcesOfType(
	 * xdaqAppsProto ); // get the first application to act on all
	 * xdaqApplication // via the *All() methods if ( !listXdaqApps.isEmpty() )
	 * xdaqAppsProto = (XdaqApplication)listXdaqApps.get(0); // define summary
	 * states List xdaqBU = xdaqAppsProto.getAll("BU"); List xdaqRU =
	 * xdaqAppsProto.getAll("RU"); List xdaqRUI = xdaqAppsProto.getAll("RUI");
	 * List xdaqTA = xdaqAppsProto.getAll("TA"); List xdaqEVM =
	 * xdaqAppsProto.getAll("EVM"); List xdaqPeerTransport =
	 * xdaqAppsProto.getAll("PeerTransportTCP"); // State Enable State enabled =
	 * new State("Enabled"); QualifiedGroup.StateVector enableConds =
	 * qg.newStateVector(); enableConds.setResultState( new State("Enabled") );
	 * 
	 * enableConds.registerConditionState(xdaqBU, enabled);
	 * enableConds.registerConditionState(xdaqRU, enabled);
	 * enableConds.registerConditionState(xdaqRUI, enabled);
	 * enableConds.registerConditionState(xdaqTA, enabled);
	 * enableConds.registerConditionState(xdaqEVM, enabled); // State Configured
	 * State configured = new State("Ready"); QualifiedGroup.StateVector
	 * configureConds = qg.newStateVector(); configureConds.setResultState( new
	 * State("AllReady"));
	 * 
	 * configureConds.registerConditionState(xdaqBU, configured);
	 * configureConds.registerConditionState(xdaqRU, configured);
	 * configureConds.registerConditionState(xdaqRUI, configured);
	 * configureConds.registerConditionState(xdaqTA, configured);
	 * configureConds.registerConditionState(xdaqEVM, configured); // State
	 * Halted State halted = new State("Halted"); QualifiedGroup.StateVector
	 * haltConds = qg.newStateVector(); haltConds.setResultState( new
	 * State("Halted"));
	 * 
	 * haltConds.registerConditionState( xdaqBU, halted );
	 * haltConds.registerConditionState( xdaqRU, halted );
	 * haltConds.registerConditionState( xdaqTA, halted );
	 * haltConds.registerConditionState( xdaqEVM, halted ); // add state vector
	 * to qualified group qg.addStateVector( configureConds );
	 * qg.addStateVector( enableConds ); qg.addStateVector( haltConds ); }
	 */
}
