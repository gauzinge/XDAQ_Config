package rcms.fsm.tkfsm;

import rcms.fm.fw.user.UserStateMachineDefinition;
import rcms.fm.fw.parameter.ParameterSet;
import rcms.statemachine.definition.State;
import rcms.statemachine.definition.StateMachineDefinitionException;

public class StateMachineDefinition extends UserStateMachineDefinition {

	/*
	 * (non-Javadoc)
	 * 
	 * @see rcms.statemachine.user.UserStateMachineDefinition#init()
	 */
	public StateMachineDefinition() throws StateMachineDefinitionException {
		
		
		//
		// Set then the objects containing the callbacks
		//
		// Transition Callbacks
		setTransitionActions(new TransitionActions());

		// Transition Failed Callbacks
		setTransitionFailedActions(new TransitionFailedActions());

		// Add a State entry and exit action allbacks
		StateActions stateActions = new StateActions();
		setEnteredStateActions(stateActions);
		setExitingStateActions(stateActions);
		//
		// States
		//
		addState(States.CREATED);
		addState(States.INITIAL);
		addState(States.HALTED);
		addState(States.PREHALTED);
		addState(States.PRESTOPPED);
		addState(States.CONFIGURED);
		addState(States.DCUCONFIGURED);
		addState(States.PRECONFIGURED);
		addState(States.ENABLED);
		addState(States.ERROR);


		//
		// Initial state
		//
		setInitialState(States.CREATED);

		//
		// Inputs (Commands)
		//
		//		ParameterSet parameterSet = new ParameterSet();
		//              parameterSet.put("RunNumber", "");
		//              Inputs.STARTNEWRUN.setParameters(parameterSet);

		addInput(Inputs.INITIALIZE);
		addInput(Inputs.INITIALISE);
		addInput(Inputs.RESTART);
		addInput(Inputs.CONFIGURE);
		addInput(Inputs.CONFIGUREDCU);
		addInput(Inputs.PRECONFIGURE);
		addInput(Inputs.HALT);
		addInput(Inputs.HALTDCU);
		addInput(Inputs.PREHALT);
		addInput(Inputs.PRESTOP);
		addInput(Inputs.ENABLE);
		addInput(Inputs.RESET);
		addInput(Inputs.COLDRESET);
		addInput(Inputs.STOP);
		//		addInput(Inputs.REFRESHSTATE);
		addInput(Inputs.SETERROR);
		//
                // add entry and exit actions
                //

		addEnteredStateAction (States.INITIAL, "InitialEntryAction");
		addExitingStateAction (States.INITIAL, "InitialExitAction");
		addEnteredStateAction (States.PRECONFIGURED, "PreConfiguredEntryAction");
		addExitingStateAction (States.PRECONFIGURED, "PreConfiguredExitAction");
		addEnteredStateAction (States.CONFIGURED, "ConfiguredEntryAction");
		addExitingStateAction (States.CONFIGURED, "ConfiguredExitAction");
		addEnteredStateAction (States.DCUCONFIGURED, "DcuConfiguredEntryAction");
		addExitingStateAction (States.DCUCONFIGURED, "DcuConfiguredExitAction");
		addEnteredStateAction (States.HALTED, "HaltedEntryAction");
		addExitingStateAction (States.HALTED, "HaltedExitAction");
		addEnteredStateAction (States.PREHALTED, "PreHaltedEntryAction");
		addExitingStateAction (States.PREHALTED, "PreHaltedExitAction");
		addEnteredStateAction (States.PRESTOPPED, "PreStoppedEntryAction");
		addExitingStateAction (States.PRESTOPPED, "PreStoppedExitAction");
		addEnteredStateAction (States.ENABLED, "EnabledEntryAction");
		addExitingStateAction (States.ENABLED, "EnabledExitAction");
		addEnteredStateAction (States.ERROR, "ErrorEntryAction");
		addExitingStateAction (States.ERROR, "ErrorExitAction");

		//
		// State Transitions
		//
	
		addTransition(Inputs.INITIALIZE, States.CREATED, States.INITIAL,
				"initializeAction", "initializeFailedAction");
		addTransition(Inputs.INITIALISE, States.INITIAL, States.HALTED,
				"initialiseAction", "initialiseFailedAction");
		addTransition(Inputs.RESTART, States.HALTED, States.INITIAL,
				"restartAction", "restartFailedAction");
		addTransition(Inputs.CONFIGUREDCU, States.HALTED, States.DCUCONFIGURED,
			      "configureDcuAction", "configureDcuFailedAction");
		addTransition(Inputs.PRECONFIGURE, States.DCUCONFIGURED, States.PRECONFIGURED,
			      "preconfigureAction", "preconfigureFailedAction");
		addTransition(Inputs.PRECONFIGURE, States.HALTED, States.PRECONFIGURED,
			      "preconfigureAction", "preconfigureFailedAction");
		addTransition(Inputs.CONFIGURE, States.PRECONFIGURED, States.CONFIGURED,
			      "configureAction", "configureFailedAction");
		addTransition(Inputs.ENABLE, States.CONFIGURED, States.ENABLED,
				"enableAction", "enableFailedAction");

		addTransition(Inputs.HALT, States.PREHALTED, States.HALTED,
				"haltAction", "haltFailedAction");
		addTransition(Inputs.STOP, States.PRESTOPPED, States.CONFIGURED,
				"stopAction", "stopFailedAction");

		addTransition(Inputs.HALTDCU, States.DCUCONFIGURED, States.HALTED,
				"haltDcuAction", "haltDcuFailedAction");
		addTransition(Inputs.PREHALT, States.CONFIGURED, States.PREHALTED,
				"prehaltAction", "prehaltFailedAction");
		addTransition(Inputs.PREHALT, States.ENABLED, States.PREHALTED,
				"prehaltAction", "prehaltFailedAction");
		addTransition(Inputs.PRESTOP, States.ENABLED, States.PRESTOPPED,
				"prestopAction", "prestopFailedAction");
		addTransition(Inputs.RESET, State.ANYSTATE, States.INITIAL,
				"resetAction", "resetFailedAction");
		addTransition(Inputs.COLDRESET, States.INITIAL, States.INITIAL,
				"coldresetAction", "coldresetFailedAction");
		// addCommand(Inputs.REFRESHSTATE, "refreshAction");
                addTransition(Inputs.SETERROR, State.ANYSTATE, States.ERROR);

	}
}
