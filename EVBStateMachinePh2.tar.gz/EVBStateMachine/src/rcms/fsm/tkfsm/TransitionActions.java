package rcms.fsm.tkfsm;

import java.util.Iterator;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Date;

import rcms.fm.fw.parameter.type.StringT;
import rcms.fm.fw.parameter.type.IntegerT;

import org.apache.log4j.Logger;

import rcms.fm.fw.user.UserActionException;
import rcms.fm.fw.user.UserActions;
import rcms.fm.fw.parameter.ParameterSet;
import rcms.fm.fw.parameter.FunctionManagerParameter;

import rcms.fm.resource.QualifiedGroup;
import rcms.fm.resource.CommandException;
import rcms.fm.resource.QualifiedResourceContainerException;
import rcms.fm.resource.qualifiedresource.XdaqApplication;
import rcms.fm.resource.qualifiedresource.XdaqExecutive;
import rcms.fm.resource.qualifiedresource.XdaqApplicationContainer;
import rcms.statemachine.definition.Input;
import rcms.statemachine.definition.State;
import rcms.utilities.runinfo.RunInfo;
import rcms.utilities.runinfo.RunInfoException;
import rcms.fm.resource.QualifiedResourceContainer;
import rcms.fm.resource.qualifiedresource.FunctionManager;
import rcms.xdaqctl.XDAQParameter;

/**
 * @author Samim Erhan
 * 
 * User Transitions Action class for an example detetor Function Manager.
 * 
 *  
 */
public class TransitionActions extends UserActions {
    static Logger logger = Logger.getLogger(TransitionActions.class);
    static String myname;

    private QualifiedGroup qualifiedGroup = null;
    //private FunctionManager firstFMClient = null;
    //private FunctionManager secondFMClient = null;


    //private Iterator listIterator = null;
    //private String firstFSMName="tkfsm1";
    //private String secondFSMName="tkfsm2";

        private List listFMChildren = null;
	private XdaqApplicationContainer xdaqAppsContainer = null;
	private XdaqApplicationContainer xdaqBU  = null;
	private XdaqApplicationContainer xdaqRU  = null;
	private XdaqApplicationContainer xdaqFU  = null;
	private XdaqApplicationContainer xdaqEVM  = null;
	private XdaqApplicationContainer xdaqSMi2oSender  = null;
	private XdaqApplicationContainer xdaqtestStorageManager  = null;
	private XdaqApplicationContainer xdaqErrorDispatcher  = null;
	private XdaqApplicationContainer xdaqCrateController  = null;
	private XdaqApplicationContainer xdaqCrateController0  = null;
	private XdaqApplicationContainer xdaqCrateController1  = null;
	private XdaqApplicationContainer xdaqDiagSentinelErrorsGrabber = null;
        private XdaqApplicationContainer xdaqGlobalErrorDispatcher = null;
	private XdaqApplicationContainer xdaqPeerTransport  = null;
	private XdaqApplicationContainer xdaqRootAnalyzer  = null;
	private XdaqApplicationContainer xdaqTrackerSupervisor  = null;
	private XdaqApplicationContainer xdaqDS  = null;
	private XdaqApplicationContainer xdaqFecSupervisor  = null;
	private XdaqApplicationContainer xdaqDcuFilter  = null;
	private XdaqApplicationContainer xdaqFed9USupervisor  = null;
	private XdaqApplicationContainer xdaqTSCSupervisor  = null;
	private XdaqApplicationContainer xdaqTTCciSupervisor  = null;
	private XdaqApplicationContainer xdaqGenericTTCciSupervisor  = null;
	private XdaqApplicationContainer xdaqGenericTCDSSupervisor  = null;
	private XdaqApplicationContainer xdaqTrackerTTCciSupervisor  = null;
	private XdaqApplicationContainer xdaqLTCSupervisor  = null;
	private XdaqApplicationContainer xdaqGenericLTCSupervisor  = null;
	private XdaqApplicationContainer xdaqTrackerLTCSupervisor  = null;
	private XdaqApplicationContainer xdaqDataBaseCache  = null;
//added for Kristian
	private XdaqApplicationContainer xdaqTTCciControl  = null;
	private XdaqApplicationContainer xdaqLTCControl  = null;
	private XdaqApplicationContainer xdaqFBO  = null;
	private XdaqApplicationContainer xdaqFRLController  = null;
	private XdaqApplicationContainer xdaqTA  = null;
        private XdaqApplicationContainer xdaqFMMController  = null;
//Rob stuff
	private XdaqApplicationContainer xdaqFUEventProcessor  = null;
        private XdaqApplicationContainer xdaqFilterUnitFramework  = null;
        private XdaqApplicationContainer xdaqCollector = null;
        private XdaqApplicationContainer xdaqSiStripCommissioningDbClient = null;
        private XdaqApplicationContainer xdaqApveSupervisor = null;
        private XdaqApplicationContainer xdaqLasSupervisor=null;

	private List listXdaqApps = null;

	private StateMachine functionManager = null;

        private RunInfo runInfo = null;

        private boolean evbConfigured = false;
        private boolean evbEnabled = false;
        private boolean ptInitialised = false;

	public void init() {
	}

	public void initializeAction() throws UserActionException {
		//
		// Some Initialization code can be put here
		//
		logger.info("DETECTOR: TransitionActions init");
		functionManager = (StateMachine)getUserFunctionManager();

		//	myname = functionManager.getName();

		String myuri =  functionManager.getURI().toString();
		int start = myuri.indexOf('=');
		int end = myuri.indexOf(',',start+1);
		showError ("Ok");
		myname = myuri.substring(start+1,end)+"["+functionManager.getName()+"]";

                logger.info ("FMlog "+new Date()+"--> "+myname+" start initializeAction()");

		qualifiedGroup = functionManager.getQualifiedGroup();
		// retrieve FMChildren for all Function managers in this Group
		listFMChildren = qualifiedGroup
				.seekQualifiedResourcesOfType(new FunctionManager());
		listXdaqApps = qualifiedGroup
				.seekQualifiedResourcesOfType(new XdaqApplication());

		try {
		    if (!listFMChildren.isEmpty()) {
			//loop on FM children
			Iterator fmIt = listFMChildren.iterator();
			while (fmIt.hasNext()) {
			    ArrayList mylist = new ArrayList();
			    mylist.add(fmIt.next());
			    qualifiedGroup.init(mylist);
			}
		    }
		} catch (Exception e) {
			String errorMess = e.getMessage();
			logger.error(errorMess);
			logger.error ("FMMlog "+new Date()+"--> "+myname+" error during init() "+errorMess);
			showError ("Error during Init()");
			throw new UserActionException(errorMess);
		}
		if (!listXdaqApps .isEmpty()) {
		    int ntry = 0;
		    int success = 0;
		    String errorMess="";
                while (ntry++ < 5 && success==0) {
		    try {
			qualifiedGroup.init();
			success=1;
		    }
		    catch (Exception e) {
			errorMess = e.getMessage();
			logger.info (errorMess);
			logger.info ("FMMlog "+new Date()+"--> "+myname+" qualifiedGroup.init() failed ! Try "+ntry);
		    }
		}
		if (success == 0) {
			logger.error ("FMMlog "+new Date()+"--> "+myname+" error during init() "+errorMess);
			showError ("Error during init()");
			throw new UserActionException(errorMess);
		}
                logger.info ("FMMlog "+new Date()+"--> "+myname+" after qualifiedGroup.init()");
		}
		/*
                QualifiedResourceContainer containerFMClients = new XdaqApplicationContainer (listFMChildren);
                containerFMClients.setMultiThreadedExecution( false );
		*/
		Iterator fmIterator = listFMChildren.iterator();
                if (listFMChildren.isEmpty())
		    logger.info ("No children FM for this FM");
                else
		    while (fmIterator.hasNext()) {
			FunctionManager aFM = (FunctionManager) fmIterator.next();
			logger.info ("Child FM: "+aFM.getResource().getName());
			/*
                        if (aFM.getResource().getName().equals(firstFSMName))
				firstFMClient = aFM;
                        if (aFM.getResource().getName().equals(secondFSMName))
				secondFMClient = aFM;
			*/
		    }
                logger.info ("FMlog "+new Date()+"--> "+myname+" after loop on FM children");
		// retrieve the XDAQ applications in this Group
		/*
		if (listXdaqApps.isEmpty()) {
			String errMsg = "Detector: No XDAQ Applications to control";
			logger.error(errMsg);
			throw new UserActionException(errMsg);
		}
		*/
       		xdaqAppsContainer = new XdaqApplicationContainer(listXdaqApps);
		Iterator listIterator = listXdaqApps.iterator();

		XdaqApplication xdaqApp = null;
		while (listIterator.hasNext()) {
			xdaqApp = (XdaqApplication) listIterator.next();
			logger.info("Application = " + xdaqApp.getApplication()
					+ " Inst = " + xdaqApp.getInstance() + " lid = "
					+ xdaqApp.getLid() + " URL"
					+ xdaqApp.getResource().getURL());
		}
		logger.info ("FMlog "+new Date()+"--> "+myname+" after loop on xdaqApps");
		xdaqBU = new XdaqApplicationContainer (
			        xdaqAppsContainer.getApplicationsOfClass("rubuilder::bu::Application")
				);
		if (xdaqBU.isEmpty()) 
		    xdaqBU = new XdaqApplicationContainer (
				    xdaqAppsContainer.getApplicationsOfClass("BU"));
		
		xdaqRU = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("rubuilder::ru::Application")
		);
		if (xdaqRU.isEmpty()) 
		    xdaqRU = new XdaqApplicationContainer (
				    xdaqAppsContainer.getApplicationsOfClass("RU"));
		xdaqFU = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("rubuilder::fu::Application")
		);
		if (xdaqFU.isEmpty()) 
		    xdaqFU = new XdaqApplicationContainer (
				    xdaqAppsContainer.getApplicationsOfClass("FU"));

		xdaqEVM = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("rubuilder::evm::Application")
		);
		if (xdaqEVM.isEmpty()) 
		    xdaqEVM = new XdaqApplicationContainer (
				    xdaqAppsContainer.getApplicationsOfClass("EVM"));

                xdaqFUEventProcessor =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("evf::FUEventProcessor")
		);
/*
		xdaqFilterUnitFramework =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("FilterUnitFramework")
		);
*/
		xdaqFilterUnitFramework =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("evf::FUResourceBroker")
		);
                xdaqCollector  =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("XdaqCollector")
		);
                xdaqSiStripCommissioningDbClient  =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("SiStripCommissioningDbClient")
		);
		xdaqSMi2oSender =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("SMi2oSender")
		);
		/*
		xdaqtestStorageManager =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("testStorageManager")
		);
		*/
		xdaqtestStorageManager =  new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("stor::StorageManager")
		);
		
		// in xdaq3.1 PeerTransportTCP has no states and is not commanded.
		// PeerTransportATCP has states and is commanded.

		xdaqPeerTransport = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("pt::atcp::PeerTransportATCP")
		);
		if (xdaqPeerTransport.isEmpty()) 
		    xdaqPeerTransport = new XdaqApplicationContainer (
				    xdaqAppsContainer.getApplicationsOfClass("PeerTransportATCP"));

		xdaqRootAnalyzer = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("RootAnalyzer")
		);
   		if (xdaqRootAnalyzer.isEmpty()) 
		xdaqRootAnalyzer = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TkRootAnalyzer")
				);
		/*
		xdaqDcuAnalyzer = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("DcuAnalyzer")
		);
		*/
                
		xdaqTrackerSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TrackerSupervisor")
		);
		if (xdaqTrackerSupervisor.isEmpty())
		    xdaqTrackerSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TrackerManager"));

		xdaqDS = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("DS")
		);
		if (! xdaqDS.isEmpty()) 
		    functionManager.getParameterSet().put(new FunctionManagerParameter<IntegerT>(Parameters.NRU ,new IntegerT(xdaqDS.getApplications().size())));
                
		xdaqFecSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("FecSupervisor")
		);

		xdaqFecSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("FecSupervisor")
		);

		xdaqDcuFilter = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("DcuFilter")
		);

		xdaqFed9USupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("Fed9USupervisor")
		);
		
		xdaqApveSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("ApveSupervisor")
		);

		
		xdaqDataBaseCache = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("DataBaseCache")
		);

		xdaqTSCSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TSCSupervisor")
		);

		xdaqTTCciSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TTCciSupervisor")
		);
		xdaqGenericTTCciSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("GenericTTCciSupervisor")
		);

		xdaqGenericTCDSSupervisor = new 
			    XdaqApplicationContainer (xdaqAppsContainer.getApplicationsOfClass("GenericTCDSSupervisor"));

		xdaqTrackerTTCciSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TkTTCciSupervisor")
		);
		xdaqLTCSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("LTCSupervisor")
		);
		xdaqGenericLTCSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("GenericLTCSupervisor")
		);
		xdaqTrackerLTCSupervisor = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TkLTCSupervisor")
		);
		xdaqErrorDispatcher = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("ErrorDispatcher")
		);
		xdaqCrateController = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("CrateController")
		);

		xdaqDiagSentinelErrorsGrabber = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("DiagSentinelErrorsGrabber")
		);
//for Kristian
		xdaqTTCciControl = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TTCciControl")
		);

		xdaqLTCControl = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("LTCControl")
		);

		xdaqFBO = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("fedbuilder::FBO")
		);

		xdaqFRLController = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("fedbuilder::FRLController")
		);


		xdaqTA = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("TA")
		);

		xdaqFMMController = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("tts::FMMController")
		);

		xdaqLasSupervisor = new XdaqApplicationContainer (
			        xdaqAppsContainer.getApplicationsOfClass("LasSupervisor")
		    );

		
				xdaqGlobalErrorDispatcher = new XdaqApplicationContainer (
				xdaqAppsContainer.getApplicationsOfClass("GlobalErrorDispatcher")
		);
		
		if (!xdaqDataBaseCache.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing DataBaseCache");
	    	sendCommandToApplication(xdaqDataBaseCache, Inputs.PREPARE, States.PREPARED);
		}
			       		
                logger.info ("FMlog "+new Date()+"--> "+myname+" end initializeAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void initialiseAction() throws UserActionException {
		State evbTargetState = rcms.fsm.common.EVBStates.READY;
		String infoMess = "Detector: Executing initialiseAction";
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start initialiseAction()");

		buildFedMask();
		if (true) {
	    // children fsm	
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();
                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 sendCommandToChildFM(aFM, Inputs.INITIALISE, States.HALTED);
		}		
		}
		/*
                sendCommandToChildFM(firstFMClient, Inputs.INITIALISE, States.HALTED);
                sendCommandToChildFM(secondFMClient, Inputs.INITIALISE, States.HALTED);
		*/
	    // Apps
		if (!xdaqPeerTransport.isEmpty()) {
		    if (!ptInitialised) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing APTs");
		   sendCommandToApplication(xdaqPeerTransport, Inputs.CONFIGURE, evbTargetState);
		   sendCommandToApplication(xdaqPeerTransport, Inputs.ENABLE, States.ENABLED);
		   ptInitialised = true;
		    }
		}

		//DcuFilter must be initialised before FecSupervisor


		if (!xdaqDataBaseCache.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing DataBaseCache");
	    	sendCommandToApplication(xdaqDataBaseCache, Inputs.INITIALISE, States.HALTED);
		}
		if (!xdaqDcuFilter.isEmpty()) {
	    	sendCommandToApplication(xdaqDcuFilter, Inputs.INITIALISE, States.HALTED);
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing DcuFilter");
		}
		if (!xdaqFecSupervisor.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FecSupervisor");
	    	sendCommandToApplication(xdaqFecSupervisor, Inputs.INITIALISE, States.HALTED);
		}
		
		if (!xdaqFed9USupervisor.isEmpty()) {
		    logger.info ("FMlog "+new Date()+"--> "+myname+" doing Fed9USupervisor");
		    //		    xdaqFed9USupervisor.setMultiThreadedExecution( false );
		    sendCommandToApplication(xdaqFed9USupervisor, Inputs.INITIALISE, States.HALTED);
		}
		if (!xdaqTrackerSupervisor.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TrackerSupervisor");
                    sendCommandToApplication(xdaqTrackerSupervisor, Inputs.INITIALISE, States.HALTED);
		}
		if (!xdaqApveSupervisor.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing ApveSupervisor");
                    sendCommandToApplication(xdaqApveSupervisor, Inputs.INITIALISE, States.HALTED);
		}
		}

                logger.info ("FMlog "+new Date()+"--> "+myname+" end initialiseAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void restartAction() throws UserActionException {

		String infoMess = "Detector: Executing restartAction";
		logger.info(infoMess);
	    // children fsm	
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();
                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 sendCommandToChildFM(aFM, Inputs.RESTART, States.INITIAL);
		}		
		}
	    // Apps
		
		if (!xdaqFed9USupervisor.isEmpty()) {
		    // 		    xdaqFed9USupervisor.setMultiThreadedExecution( false );
		    sendCommandToApplication(xdaqFed9USupervisor,Inputs.DESTROY, States.INITIAL);
		}
		
		if (!xdaqDcuFilter.isEmpty()) 
	    	sendCommandToApplication(xdaqDcuFilter,Inputs.DESTROY, States.INITIAL);
		if (!xdaqFecSupervisor.isEmpty()) 
	    	sendCommandToApplication(xdaqFecSupervisor, new Input("Destroy"), States.INITIAL);
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void preconfigureAction() throws UserActionException {

		String infoMess = "Detector: Executing preconfigureAction";
		logger.info(infoMess);
		State evbTargetState = rcms.fsm.common.EVBStates.READY;
                logger.info ("FMlog "+new Date()+"--> "+myname+" start preconfigureAction()");
		String runNumber = ((StringT)functionManager.getParameterSet().get(Parameters.RUN_NUMBER).getValue()).getString();
		String runType = ((StringT)functionManager.getParameterSet().get(Parameters.RUN_TYPE).getValue()).getString();
                String fedReinit = ((StringT) functionManager.getParameterSet().get(Parameters.FED_REINIT).getValue()).getString();
                String fedFastinit = ((StringT) functionManager.getParameterSet().get(Parameters.FED_FASTINIT).getValue()).getString();
                logger.info ("(Slave FSM) Run Number is "+runNumber);
                logger.info ("(Slave FSM) Run Type is "+runType);
                logger.info ("(Slave FSM) ReinitialiseFeds is "+fedReinit);
                logger.info ("(Slave FSM) FastInitMode is "+fedReinit);
//Connect to Runinfo
//		if (! runInfo.equals("boh"))
		    runInfo = new RunInfo(functionManager.getRunInfoConnector(),new Integer(0), new Integer(runNumber));

		
//we pass the run number to the TrackerSupervisor
		if ( !xdaqTrackerSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunFromRCMS");
			    xdaqParameter.setValue("RunFromRCMS",runNumber);
			    xdaqParameter.send();
			    xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunTypeName");
			    xdaqParameter.setValue("RunTypeName",runType);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number/Type in TrackerSupervisor",e);
			}
		    }
		}
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> TrackerSupervisor");
		if ( !xdaqFed9USupervisor.isEmpty() ) {
                    List tSupList= xdaqFed9USupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number/Type in Fed(USupervisor",e);
			}
		    }
		}
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> Fed9USupervisor");
		if ( !xdaqTrackerLTCSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerLTCSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunTypeName");
			    xdaqParameter.setValue("RunTypeName",runType);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in TkLTCSupervisor",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunType --> TkLTCSupervisor");
		}
		if ( !xdaqTrackerTTCciSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerTTCciSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunTypeName");
			    xdaqParameter.setValue("RunTypeName",runType);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in TkTTCciSupervisor",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunType --> TkTTCciSupervisor");
		}
//we pass the run number to the RootAnalyzer
		if ( !xdaqRootAnalyzer.isEmpty() ) {
                    List tSupList= xdaqRootAnalyzer.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunFromRCMS");
			    xdaqParameter.setValue("RunFromRCMS",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in RootAnalyzer",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> RootAnalyzer");
		}
//we pass the run number to the GlobalErrorDispatcher
		if ( !xdaqGlobalErrorDispatcher.isEmpty() ) {
                    List tSupList= xdaqGlobalErrorDispatcher.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunFromRCMS");
			    xdaqParameter.setValue("RunFromRCMS",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in GlobalErrorDispatcher",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> GlobalErrorDispatcher");
		}
		
//we pass the run number to the FilterUnitFramework
		if ( !xdaqFilterUnitFramework.isEmpty() ) {
                    List tSupList= xdaqFilterUnitFramework.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in FilterUnitFramework",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> FilterUnitFramework");
		}
//we pass the run number to the xdaqFUEventProcessor
		if ( !xdaqFUEventProcessor.isEmpty() ) {
                    List tSupList= xdaqFUEventProcessor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in xdaqFUEventProcessor",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> xdaqFUEventProcessor");
		}
//we pass the run number to the testStorageManager
		if ( !xdaqtestStorageManager.isEmpty() ) {
                    List tSupList= xdaqtestStorageManager.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in testStorageManager",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> testStorageManager");
		}
		
		
		if ( !xdaqFed9USupervisor.isEmpty() ) {
                    List fSupList= xdaqFed9USupervisor.getApplications();
		    Iterator fSup = fSupList.iterator();
                    while (fSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)fSup.next();
			try {
			    String[] fedPar = new String[] {"ReinitialiseFeds","FastInitMode"};
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select(fedPar);
			    xdaqParameter.setValue("ReinitialiseFeds",fedReinit);
			    xdaqParameter.setValue("FastInitMode",fedFastinit);
			    xdaqParameter.send();
			    XDAQParameter xdaqParameter2 =  t.getXDAQParameter();
			    String s1=xdaqParameter2.getValue("ReinitialiseFeds");
			    String s2=xdaqParameter2.getValue("FastInitMode");

			    logger.info ("Slave fsm: "+t.getName()+" ReinitialiseFeds set "+fedReinit+" read back "+ s1);
			    logger.info ("Slave fsm: "+t.getName()+" FastInitMode set "+fedFastinit+" read back "+ s2);
			    if  (!s1.equals(fedReinit)) 
				logger.info ("Slave fsm: mismatch fedReinit "+fedReinit+" "+s1);
			    if  (!s2.equals(fedFastinit)) 
				logger.info ("Slave fsm: mismatch fedFastinit "+fedFastinit+" "+s2);
			   
			} catch (Exception e) {
			    logger.error ("Slave fsm Error setting ",e);
			}
		    }
		}
	        
                logger.info ("FMlog "+new Date()+"--> "+myname+" after ReinitialiseFeds stuff");
		
		if (true) {
	    // children fsm	
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();
                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 sendCommandToChildFM(aFM, Inputs.CONFIGURE, States.CONFIGURED);
		}		
		}



		// send Configure only to FEC CrateControllers

		if (!xdaqCrateController.isEmpty() && functionManager.getName().equals("FecStateMachine")) {
		    sendCommandToApplication(xdaqCrateController, Inputs.CONFIGURE, States.CONFIGURED);
		}

                if (!xdaqErrorDispatcher.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing ErrorDispatcher");
		    sendCommandToApplication(xdaqErrorDispatcher, Inputs.CONFIGURE, States.CONFIGURED);
		}
                if (!xdaqDiagSentinelErrorsGrabber.isEmpty()) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing DiagSentinelEGs");
		    sendCommandToApplication(xdaqDiagSentinelErrorsGrabber, Inputs.CONFIGURE, States.CONFIGURED);
		}
		if ( !xdaqDataBaseCache.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing DBCache");
		   sendCommandToApplication(xdaqDataBaseCache, Inputs.CONFIGURE, States.CONFIGURED);
		}
		/*
		if ( !xdaqCollector.isEmpty() ) {
		    logger.info ("FMlog "+new Date()+"--> "+myname+" doing xdaqCollector");
		    sendCommandToApplication(xdaqCollector, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqSiStripCommissioningDbClient.isEmpty() ) {
		    logger.info ("FMlog "+new Date()+"--> "+myname+" doing SiStripCommissioningDbClient");
		    sendCommandToApplication(xdaqSiStripCommissioningDbClient, Inputs.CONFIGURE, evbTargetState);
		}
		*/
                if (!evbConfigured) {
		    if ( !xdaqBU.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing BUs");
			sendCommandToApplication(xdaqBU, Inputs.CONFIGURE, evbTargetState);
		    }
		    if ( !xdaqRU.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing RUs");
			sendCommandToApplication(xdaqRU, Inputs.CONFIGURE, evbTargetState);
		    }
		    if ( !xdaqFU.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FUs");
			sendCommandToApplication(xdaqFU, Inputs.CONFIGURE, evbTargetState);
		    }
		    if ( !xdaqFilterUnitFramework.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FUFramework");
			sendCommandToApplication(xdaqFilterUnitFramework, Inputs.CONFIGURE, evbTargetState);
		    }
		    if ( !xdaqEVM.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing EVMs");
			sendCommandToApplication(xdaqEVM, Inputs.CONFIGURE, evbTargetState);
		    }
		    evbConfigured = true;
		}
		/*
		if ( !xdaqSMi2oSender.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing SMi2oSenders");
		   sendCommandToApplication(xdaqSMi2oSender, Inputs.CONFIGURE, evbTargetState);
		}
		*/
		if ( !xdaqtestStorageManager.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing StorageManagers");
		   sendCommandToApplication(xdaqtestStorageManager, Inputs.CONFIGURE, evbTargetState);
		}

		if ( !xdaqFUEventProcessor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FUEventProcessor");
		   sendCommandToApplication(xdaqFUEventProcessor, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqTSCSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TSCSups");
		   sendCommandToApplication(xdaqTSCSupervisor, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqLTCSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" LTCSups");
		   sendCommandToApplication(xdaqLTCSupervisor, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqGenericLTCSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing GenericLTCSups");
		   sendCommandToApplication(xdaqGenericLTCSupervisor, Inputs.TCONFIGURE, States.TCONFIGURED);
		}
		if ( !xdaqTrackerLTCSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TrackerLTCSups");
		   sendCommandToApplication(xdaqTrackerLTCSupervisor, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqTTCciSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TTCciSups");
		   sendCommandToApplication(xdaqTTCciSupervisor, Inputs.CONFIGURE, evbTargetState);
		}

		if ( !xdaqGenericTCDSSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing GenericTCDSSups");
		   sendCommandToApplication(xdaqGenericTCDSSupervisor, Inputs.CONFIGURE, States.CONFIGURED);
		}
		if ( !xdaqGenericTTCciSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing GenericTTCciSups");
		   sendCommandToApplication(xdaqGenericTTCciSupervisor, Inputs.TCONFIGURE, States.TCONFIGURED);
		}
		if ( !xdaqTrackerTTCciSupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TrackerTTCciSups");
		   sendCommandToApplication(xdaqTrackerTTCciSupervisor, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqFecSupervisor.isEmpty() ) {

                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FecSups");
		//		   xdaqFecSupervisor.setMultiThreadedExecution( false );
		   sendCommandToApplication(xdaqFecSupervisor, Inputs.CONFIGURE, States.CONFIGURED);
		   //   xdaqFecSupervisor.setMultiThreadedExecution( true );
		}

		if ( !xdaqDcuFilter.isEmpty() ) 
		   sendCommandToApplication(xdaqDcuFilter, Inputs.CONFIGURE, States.CONFIGURED);

		if ( !xdaqFed9USupervisor.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FedSupss");
		//	    xdaqFed9USupervisor.setMultiThreadedExecution( false );
		    sendCommandToApplication(xdaqFed9USupervisor, Inputs.CONFIGURE, States.CONFIGURED);
		    //    xdaqFed9USupervisor.setMultiThreadedExecution( true );
		}
		if ( !xdaqRootAnalyzer.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing RootAnalyzers");
		   sendCommandToApplication(xdaqRootAnalyzer, Inputs.CONFIGURE, States.CONFIGURED);
		}
//for Kristian
		if ( !xdaqTTCciControl.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TTCciControl");
		   sendCommandToApplication(xdaqTTCciControl, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqLTCControl.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing LTCControls");
		   sendCommandToApplication(xdaqLTCControl, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqFBO.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FBOs");
		   sendCommandToApplication(xdaqFBO, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqFRLController.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FRLControllers");
		   sendCommandToApplication(xdaqFRLController, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqTA.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing TAs");
		   sendCommandToApplication(xdaqTA, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqFMMController.isEmpty() ) {
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing FMMControllers");
		   sendCommandToApplication(xdaqFMMController, Inputs.CONFIGURE, evbTargetState);
		}
		if ( !xdaqApveSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqApveSupervisor, Inputs.CONFIGURE, States.CONFIGURED);

		}

 		if ( !xdaqLasSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqLasSupervisor, Inputs.CONFIGURE, evbTargetState);

		

                logger.info ("FMlog "+new Date()+"--> "+myname+" end preconfigureAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void configureAction() throws UserActionException {
	    String infoMess = "Detector: Executing configureAction";
	    logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start configureAction()");
		// Configure FED CrateControllers here
		if (!xdaqCrateController.isEmpty() && functionManager.getName().equals("FedStateMachine")) {
		    try {
			List listCC0 =new ArrayList();
			List listCC1 =new ArrayList();
			List listCC = xdaqCrateController.getApplications();
			Iterator ccIt = listCC.iterator();
			XdaqApplication ccApp = null;
			
			while (ccIt.hasNext()) {
			    ccApp = (XdaqApplication) ccIt.next();
			    try {
			    XDAQParameter xdaqParameter = ccApp.getXDAQParameter();
			    if (xdaqParameter.getValue("FedFirstUpload").equals("true"))listCC0.add(ccApp);
			    else listCC1.add(ccApp);
			    }
			    catch (Exception e) {
			    logger.error ("Error reading FedFirstUpload from CrateControllers",e);
			    }
			}
			xdaqCrateController0=new XdaqApplicationContainer(listCC0);
			xdaqCrateController1=new XdaqApplicationContainer(listCC1);
			logger.info ("FMlog "+new Date()+"--> "+myname+" CrateControllers "+listCC0.size()+" "+listCC1.size()+" "+listCC.size());
		    }
		    catch (Exception e) {
			logger.error ("Error handling CrateController lists",e);
		    }
		    sendCommandToApplication(xdaqCrateController0, Inputs.CONFIGURE, States.CONFIGURED);
		    sendCommandToApplication(xdaqCrateController1, Inputs.CONFIGURE, States.CONFIGURED);
		}

		if ( !xdaqDS.isEmpty() ) {
		    //disable multithread
                xdaqDS.setMultiThreadedExecution( false );
                logger.info ("FMlog "+new Date()+"--> "+myname+" doing DSs");
		   sendCommandToApplication(xdaqDS, Inputs.CONFIGURE, States.CONFIGURED);
		   // reenable it
                xdaqDS.setMultiThreadedExecution( true );
		}

		if ( !xdaqTrackerSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqTrackerSupervisor, Inputs.CONFIGURE, States.CONFIGURED);
		
		if (!xdaqFecSupervisor.isEmpty()) 
		    sendCommandToApplication(xdaqFecSupervisor, Inputs.ENABLE, States.ENABLED);		

                logger.info ("FMlog "+new Date()+"--> "+myname+" end configureAction()");
		
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void configureDcuAction() throws UserActionException {
	    String infoMess = "Detector: Executing configureDcuAction";
	    logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start configureDcuAction()");
		if ( !xdaqFecSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqFecSupervisor, Inputs.CONFIGUREDCU, States.DCUCONFIGURED);
                logger.info ("FMlog "+new Date()+"--> "+myname+" end configureDcuAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void enableAction() throws UserActionException {
		String infoMess = "Detector: Executing EnableAction";
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start enableAction()");
	    // children fsm	
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();
                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 sendCommandToChildFM(aFM, Inputs.ENABLE, States.ENABLED);
		}		
		}
		passRunNumber();
		if (!xdaqDcuFilter.isEmpty()) 
		    sendCommandToApplication(xdaqDcuFilter, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqTrackerSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    String runType = xdaqParameter.getValue("RunType");
			    writeRunInfo ("RunType",runType);
			    break; 
			} catch (Exception e) {
			    logger.error ("Error reading RunType from TrackerSupervisor",e);
			}
		    }
		}

		if ( !xdaqDataBaseCache.isEmpty() ) 
			sendCommandToApplication(xdaqDataBaseCache, Inputs.ENABLE, States.ENABLED);
		/*
		    if ( !xdaqCollector.isEmpty() ) 
			sendCommandToApplication(xdaqCollector, Inputs.ENABLE, States.ENABLED);
		    if ( !xdaqSiStripCommissioningDbClient.isEmpty() ) 
			sendCommandToApplication(xdaqSiStripCommissioningDbClient, Inputs.ENABLE, States.ENABLED);
		*/
                if (!evbEnabled) {
		    if ( !xdaqtestStorageManager.isEmpty() ) 
		   sendCommandToApplication(xdaqtestStorageManager, Inputs.ENABLE, States.ENABLED);
		    if ( !xdaqRU.isEmpty() ) 
			sendCommandToApplication(xdaqRU, Inputs.ENABLE, States.ENABLED);
		    if ( !xdaqFU.isEmpty() ) 
			sendCommandToApplication(xdaqFU, Inputs.ENABLE, States.ENABLED);
		    if ( !xdaqFilterUnitFramework.isEmpty() ) 
			sendCommandToApplication(xdaqFilterUnitFramework, Inputs.ENABLE, States.ENABLED);
		    if ( !xdaqEVM.isEmpty() ) 
			sendCommandToApplication(xdaqEVM, Inputs.ENABLE, States.ENABLED);
		    if ( !xdaqBU.isEmpty() )
			sendCommandToApplication(xdaqBU, Inputs.ENABLE, States.ENABLED);
		    //		    evbEnabled = true;
		} 
		/*
		if ( !xdaqSMi2oSender.isEmpty() ) 
		   sendCommandToApplication(xdaqSMi2oSender, Inputs.ENABLE, States.ENABLED);
		*/

		if ( !xdaqFUEventProcessor.isEmpty() ) 
		   sendCommandToApplication(xdaqFUEventProcessor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqFed9USupervisor.isEmpty() ) {
		    // xdaqFed9USupervisor.setMultiThreadedExecution( false );
		    sendCommandToApplication(xdaqFed9USupervisor, Inputs.ENABLE, States.ENABLED);
		    // xdaqFed9USupervisor.setMultiThreadedExecution( true );
		}
		if ( !xdaqTSCSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqTSCSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqLTCSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqLTCSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqGenericLTCSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqGenericLTCSupervisor, Inputs.TENABLE, States.TENABLED);
		if ( !xdaqTrackerLTCSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqTrackerLTCSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqTTCciSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqTTCciSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqGenericTCDSSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqGenericTCDSSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqGenericTTCciSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqGenericTTCciSupervisor, Inputs.TENABLE, States.TENABLED);
		if ( !xdaqTrackerTTCciSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqTrackerTTCciSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqDS.isEmpty() ) 
		   sendCommandToApplication(xdaqDS, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqTrackerSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqTrackerSupervisor, Inputs.ENABLE, States.ENABLED);
//for Kristian
		if ( !xdaqTTCciControl.isEmpty() ) 
		   sendCommandToApplication(xdaqTTCciControl, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqLTCControl.isEmpty() ) 
		   sendCommandToApplication(xdaqLTCControl, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqFBO.isEmpty() ) 
		   sendCommandToApplication(xdaqFBO, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqFRLController.isEmpty() ) 
		   sendCommandToApplication(xdaqFRLController, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqTA.isEmpty() ) 
		   sendCommandToApplication(xdaqTA, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqFMMController.isEmpty() ) 
		   sendCommandToApplication(xdaqFMMController, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqApveSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqApveSupervisor, Inputs.ENABLE, States.ENABLED);
		if ( !xdaqLasSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqLasSupervisor, Inputs.ENABLE, States.ENABLED);

                logger.info ("FMlog "+new Date()+"--> "+myname+" end enableAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void haltDcuAction() throws UserActionException {
		String infoMess = "Executing haltDcuAction";
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start haltDcuAction()");
		if ( !xdaqFecSupervisor.isEmpty() ) 
		    sendCommandToApplication(xdaqFecSupervisor, Inputs.HALTDCU, States.HALTED);
                logger.info ("FMlog "+new Date()+"--> "+myname+" end haltDcuAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void prestopAction() throws UserActionException {
	    // we need to be sure that the TrackerSupervisor is Halted first
		String infoMess = "Executing prestopAction";
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start prestopAction()");
		if ( !xdaqTrackerSupervisor.isEmpty() ) {
		    logger.info("tkfsm: stopping TrackerSupervisor");
		    sendCommandToApplication(xdaqTrackerSupervisor, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
                logger.info ("FMlog "+new Date()+"--> "+myname+" end prestopAction()");
	}
	/**
	 * 
	 * @throws UserActionException
	 */
	public void prehaltAction() throws UserActionException {
	    // we need to be sure that the TrackerSupervisor is Halted first
		String infoMess = "Executing prehaltAction";
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start prehaltAction()");
		if ( !xdaqTrackerSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TrackerSupervisor");
		    sendCommandToApplication(xdaqTrackerSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
                logger.info ("FMlog "+new Date()+"--> "+myname+" end prehaltAction()");
	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void haltAction() throws UserActionException {
		String infoMess = "Executing haltAction";
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start haltAction()");
	    // children fsm	
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();
                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 sendCommandToChildFM(aFM, Inputs.HALT, States.HALTED);
		}		
		}
		/*
		if ( !xdaqTrackerSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TrackerSupervisor");
		    sendCommandToApplication(xdaqTrackerSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		*/

		if ( !xdaqDcuFilter.isEmpty() ) 
		   sendCommandToApplication(xdaqDcuFilter, Inputs.HALT, States.HALTED);


		if ( !xdaqDataBaseCache.isEmpty() ) { 
		    logger.info("tkfsm: halting DataBaseCache");
		    sendCommandToApplication(xdaqDataBaseCache, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}

		if ( !xdaqFecSupervisor.isEmpty() ) { 
		    logger.info("tkfsm: halting FecSupervisor");
		    sendCommandToApplication(xdaqFecSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqTSCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TSCSupervisor");
		   sendCommandToApplication(xdaqTSCSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqLTCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting LTCSupervisor");
		   sendCommandToApplication(xdaqLTCSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqGenericLTCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting GenericLTCSupervisor");
		   sendCommandToApplication(xdaqGenericLTCSupervisor, Inputs.TRESET, States.THALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqTrackerLTCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TrackerLTCSupervisor");
		   sendCommandToApplication(xdaqTrackerLTCSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqTTCciSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TTCciSupervisor");
		   sendCommandToApplication(xdaqTTCciSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqGenericTCDSSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting GenericTCDSSupervisor");
		   sendCommandToApplication(xdaqGenericTCDSSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqGenericTTCciSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting GenericTTCciSupervisor");
		   sendCommandToApplication(xdaqGenericTTCciSupervisor, Inputs.TRESET, States.THALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqTrackerTTCciSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TrackerTTCciSupervisor");
		   sendCommandToApplication(xdaqTrackerTTCciSupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqFed9USupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting Fed9USupervisor");
		    //		    xdaqFed9USupervisor.setMultiThreadedExecution( false );
		    sendCommandToApplication(xdaqFed9USupervisor, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqDS.isEmpty() ) {
		    logger.info("tkfsm: halting DS");
		   sendCommandToApplication(xdaqDS, Inputs.HALT, States.HALTED); 
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqRootAnalyzer.isEmpty() ) {
		    logger.info("FMlog "+new Date()+" tkfsm: halting RootAnalyzer");
		   sendCommandToApplication(xdaqRootAnalyzer, Inputs.HALT, States.HALTED);
		    logger.info("FMlog "+new Date()+" tkfsm : halted");
		}

		/*
		if ( !xdaqSiStripCommissioningDbClient.isEmpty() ) {
		    logger.info("tkfsm: halting SiStripCommissioningDbClient");
		   sendCommandToApplication(xdaqSiStripCommissioningDbClient, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		*/
		/*
		if ( !xdaqCollector.isEmpty() ) {
		    logger.info("tkfsm: halting xdaqCollector");
		   sendCommandToApplication(xdaqCollector, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		*/
		/*
		if ( !xdaqSMi2oSender.isEmpty() ) { 
		    logger.info("tkfsm: halting xdaqSMi2oSender");
		   sendCommandToApplication(xdaqSMi2oSender, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		*/
                if (!xdaqErrorDispatcher.isEmpty()) {
		    logger.info("tkfsm: halting ErrorDispatcher");
		    sendCommandToApplication(xdaqErrorDispatcher, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}
		
                if (!xdaqCrateController.isEmpty())
		    sendCommandToApplication(xdaqCrateController, Inputs.HALT, States.HALTED);
		
                if (!xdaqDiagSentinelErrorsGrabber.isEmpty()) {
		    logger.info("tkfsm: halting DiagSentinelErrorsGrabber");
		    sendCommandToApplication(xdaqDiagSentinelErrorsGrabber, Inputs.HALT, States.HALTED);
		    logger.info("tkfsm: halted");
		}


		// now the evb applications do not halt anymore
		/*
		  now they do again
		 */
		if ( !xdaqEVM.isEmpty() ) 
		   sendCommandToApplication(xdaqEVM, Inputs.HALT, States.HALTED);
		if ( !xdaqBU.isEmpty() ) 
		   sendCommandToApplication(xdaqBU, Inputs.HALT, States.HALTED);
		if ( !xdaqRU.isEmpty() ) 
		   sendCommandToApplication(xdaqRU, Inputs.HALT, States.HALTED);
		if ( !xdaqFU.isEmpty() ) 
		   sendCommandToApplication(xdaqFU, Inputs.HALT, States.HALTED);
		if ( !xdaqFilterUnitFramework.isEmpty() ) 
		   sendCommandToApplication(xdaqFilterUnitFramework, Inputs.HALT, States.HALTING);
		if ( !xdaqFUEventProcessor.isEmpty() ) {
		    logger.info("tkfsm: stopping FUEventProcessor");
		    sendCommandToApplication(xdaqFUEventProcessor, Inputs.STOP, rcms.fsm.common.EVBStates.READY);
		    logger.info("tkfsm: halting FUEventProcessor");
		   sendCommandToApplication(xdaqFUEventProcessor, Inputs.HALT, States.HALTING);
		    logger.info("tkfsm: halted");
		}
		if ( !xdaqtestStorageManager.isEmpty() ) {
		    logger.info("tkfsm: halting xdaqtestStorageManager");
		   sendCommandToApplication(xdaqtestStorageManager, Inputs.HALT, States.HALTING);
		    logger.info("tkfsm: halted");
		}
		/*
		*/
//for Kristian
		if ( !xdaqTTCciControl.isEmpty() ) 
		   sendCommandToApplication(xdaqTTCciControl, Inputs.HALT, States.HALTED);
		if ( !xdaqLTCControl.isEmpty() ) 
		   sendCommandToApplication(xdaqLTCControl, Inputs.HALT, States.HALTED);
		if ( !xdaqFBO.isEmpty() ) 
		   sendCommandToApplication(xdaqFBO, Inputs.HALT, States.HALTED);
		if ( !xdaqFRLController.isEmpty() ) 
		   sendCommandToApplication(xdaqFRLController, Inputs.HALT, States.HALTED);
		if ( !xdaqTA.isEmpty() ) 
		   sendCommandToApplication(xdaqTA, Inputs.HALT, States.HALTED);
		if ( !xdaqFMMController.isEmpty() ) 
		   sendCommandToApplication(xdaqFMMController, Inputs.HALT, States.HALTED);
		if ( !xdaqApveSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqApveSupervisor, Inputs.HALT, States.HALTED);
		if ( !xdaqLasSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqLasSupervisor, Inputs.HALT, States.HALTED);

                logger.info ("FMlog "+new Date()+"--> "+myname+" end haltAction()");

	}

	/**
	 * 
	 * @throws UserActionException
	 */
	public void stopAction() throws UserActionException {
		String infoMess = "Executing stopAction";
		State evbTargetState = rcms.fsm.common.EVBStates.READY;
		logger.info(infoMess);
                logger.info ("FMlog "+new Date()+"--> "+myname+" start stopAction()");
	    // children fsm	
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();
                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 sendCommandToChildFM(aFM, Inputs.STOP, States.CONFIGURED);
		}		
		}

		if ( !xdaqDcuFilter.isEmpty() ) 
		   sendCommandToApplication(xdaqDcuFilter, Inputs.STOP, States.CONFIGURED);


		if ( !xdaqDataBaseCache.isEmpty() ) { 
		    logger.info("tkfsm: halting DataBaseCache");
		    sendCommandToApplication(xdaqDataBaseCache, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		/*
		if ( !xdaqFecSupervisor.isEmpty() ) { 
		    logger.info("tkfsm: halting FecSupervisor");
		    sendCommandToApplication(xdaqFecSupervisor, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		*/
		if ( !xdaqTSCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TSCSupervisor");
		   sendCommandToApplication(xdaqTSCSupervisor, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqLTCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting LTCSupervisor");
		   sendCommandToApplication(xdaqLTCSupervisor, Inputs.HALT, States.HALTED);
		   sendCommandToApplication(xdaqLTCSupervisor, Inputs.CONFIGURE, evbTargetState);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqGenericLTCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting GenericLTCSupervisor");
		    sendCommandToApplication(xdaqGenericLTCSupervisor, Inputs.TRESET, States.THALTED);
		    sendCommandToApplication(xdaqGenericLTCSupervisor, Inputs.TCONFIGURE, States.TCONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqTrackerLTCSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TrackerLTCSupervisor");
		    sendCommandToApplication(xdaqTrackerLTCSupervisor, Inputs.HALT, States.HALTED);
		    sendCommandToApplication(xdaqTrackerLTCSupervisor, Inputs.CONFIGURE, evbTargetState);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqTTCciSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TTCciSupervisor");
		    sendCommandToApplication(xdaqTTCciSupervisor, Inputs.HALT, States.HALTED);
		    sendCommandToApplication(xdaqTTCciSupervisor, Inputs.CONFIGURE, evbTargetState);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqGenericTCDSSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting GenericTCDSSupervisor");
		    sendCommandToApplication(xdaqGenericTCDSSupervisor, Inputs.HALT, States.HALTED);
		    sendCommandToApplication(xdaqGenericTCDSSupervisor, Inputs.CONFIGURE, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqGenericTTCciSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting GenericTTCciSupervisor");
		    sendCommandToApplication(xdaqGenericTTCciSupervisor, Inputs.TRESET, States.THALTED);
		    sendCommandToApplication(xdaqGenericTTCciSupervisor, Inputs.TCONFIGURE, States.TCONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqTrackerTTCciSupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting TrackerTTCciSupervisor");
		   sendCommandToApplication(xdaqTrackerTTCciSupervisor, Inputs.HALT, States.HALTED);
		   sendCommandToApplication(xdaqTrackerTTCciSupervisor, Inputs.CONFIGURE, evbTargetState);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqFed9USupervisor.isEmpty() ) {
		    logger.info("tkfsm: halting Fed9USupervisor");
		    //		    xdaqFed9USupervisor.setMultiThreadedExecution( false );
		    sendCommandToApplication(xdaqFed9USupervisor, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqDS.isEmpty() ) {
		    logger.info("tkfsm: halting DS");
		   sendCommandToApplication(xdaqDS, Inputs.STOP, States.CONFIGURED); 
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqRootAnalyzer.isEmpty() ) {
		    logger.info("FMlog "+new Date()+" tkfsm: halting RootAnalyzer");
		   sendCommandToApplication(xdaqRootAnalyzer, Inputs.STOP, States.CONFIGURED);
		    logger.info("FMlog "+new Date()+" tkfsm : stopped");
		}
                if (!xdaqErrorDispatcher.isEmpty()) {
		    logger.info("tkfsm: halting ErrorDispatcher");
		    sendCommandToApplication(xdaqErrorDispatcher, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}
		
                if (!xdaqCrateController.isEmpty())
		    sendCommandToApplication(xdaqCrateController, Inputs.STOP, States.CONFIGURED);
		
                if (!xdaqDiagSentinelErrorsGrabber.isEmpty()) {
		    logger.info("tkfsm: halting DiagSentinelErrorsGrabber");
		    sendCommandToApplication(xdaqDiagSentinelErrorsGrabber, Inputs.STOP, States.CONFIGURED);
		    logger.info("tkfsm: stopped");
		}


		// now the evb applications do not halt anymore
		/*
		  now they do again
		 */
		if ( !xdaqEVM.isEmpty() ) 
		   sendCommandToApplication(xdaqEVM, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqBU.isEmpty() ) 
		   sendCommandToApplication(xdaqBU, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqRU.isEmpty() ) 
		   sendCommandToApplication(xdaqRU, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqFU.isEmpty() ) 
		   sendCommandToApplication(xdaqFU, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqFilterUnitFramework.isEmpty() ) 
		   sendCommandToApplication(xdaqFilterUnitFramework, Inputs.STOP, States.STOPPING);
		if ( !xdaqFUEventProcessor.isEmpty() ) {
		    logger.info("tkfsm: stopping FUEventProcessor");
		    sendCommandToApplication(xdaqFUEventProcessor, Inputs.STOP, rcms.fsm.common.EVBStates.READY);
		    logger.info("tkfsm: stopped");
		}
		if ( !xdaqtestStorageManager.isEmpty() ) {
		    logger.info("tkfsm: halting xdaqtestStorageManager");
		   sendCommandToApplication(xdaqtestStorageManager, Inputs.STOP, States.STOPPING);
		    logger.info("tkfsm: stopped");
		}
		/*
		*/
//for Kristian
		if ( !xdaqTTCciControl.isEmpty() ) 
		   sendCommandToApplication(xdaqTTCciControl, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqLTCControl.isEmpty() ) 
		   sendCommandToApplication(xdaqLTCControl, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqFBO.isEmpty() ) 
		   sendCommandToApplication(xdaqFBO, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqFRLController.isEmpty() ) 
		   sendCommandToApplication(xdaqFRLController, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqTA.isEmpty() ) 
		   sendCommandToApplication(xdaqTA, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqFMMController.isEmpty() ) 
		   sendCommandToApplication(xdaqFMMController, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqApveSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqApveSupervisor, Inputs.STOP, States.CONFIGURED);
		if ( !xdaqLasSupervisor.isEmpty() ) 
		   sendCommandToApplication(xdaqLasSupervisor, Inputs.STOP, evbTargetState );

                logger.info ("FMlog "+new Date()+"--> "+myname+" end stopAction()");

	}

	public void resetAction() throws UserActionException {
		logger.info("RCMS FM: Executing resetAction");
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();

                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 logger.info ("FM "+aFM.getResource().getName()+" will be reset !");
		 sendCommandToChildFM(aFM, Inputs.RESET, States.INITIAL);
		}
		}
		// kill local applications ???
                logger.info ("End of ResetAction");
	}

	public void coldresetAction() throws UserActionException {
		logger.info("RCMS FM: Executing coldresetAction");
		if (!listFMChildren.isEmpty()) {
                Iterator fmIterator= listFMChildren.iterator();

                while(fmIterator.hasNext()) {
		 FunctionManager aFM = (FunctionManager) fmIterator.next();
		 logger.info ("FM "+aFM.getResource().getName()+" will be reset !");
		 sendCommandToChildFM(aFM, Inputs.COLDRESET, States.INITIAL);
		}
		}
		//sleep 1 sec; to be replaced by sending ColdReset to apps
		try {
		    Thread.sleep(1000);
		} catch (InterruptedException e){
		    e.printStackTrace();
		    throw new  UserActionException("Thread sleep failed while waiting 1 sec");
		}
		
                logger.info ("End of ColdResetAction");
	}

	/**
	 * 
	 * @param application
	 * @param command
	 * @param targetState
	 * @throws UserActionException
	 */
	public void sendCommandToApplication(XdaqApplicationContainer app,
			Input command, State targetState) throws UserActionException {
	    int sleeptime=40;
	    boolean hasFailed=false;
	    boolean isFine=true;
	    int napps=0,nsend=0;
	    List appList=null;
	    Iterator appIterator;
	    XdaqApplication application;
	    String appName=null;
            State appState;
	    if(app.isEmpty() ) return;
	    appList=app.getApplications();
	    appIterator=appList.iterator();
	    application=(XdaqApplication) appIterator.next();
	    appName=application.getName();
	    napps=appList.size();

	    logger.info ("FMsendlog "+new Date()+"--> "+myname+" Sending "+command+" to "+napps+" applications "+appName +" (multiThreadedExecution is "+app.isMultiThreadedExecution()+")");
	    Map stateMap = null;

		try {
		    // execute command
		    stateMap = app.execute(command);
		    
		} catch (QualifiedResourceContainerException ce) {
		    String errorMess = "FMlog "+new Date()+"--> "+myname+" send " + command
			+ " on application list failed ";
		    logger.error(errorMess + ce.getMessage());
		    errorMess += "\nApplication exceptions: \n";
		    Set excSet=ce.getCommandExceptionMap().keySet();
		    appIterator = excSet.iterator();
		    while (appIterator.hasNext()) {
			application = (XdaqApplication) appIterator.next();
			errorMess += application.getName() + ": " + ((CommandException)ce.getCommandExceptionMap().get(application)).getMessage();
			Throwable ex = (Throwable) ce.getCommandExceptionMap().get(application);
			while ((ex=ex.getCause())!= null) {
			    errorMess += "\n Caused by: " + ex.getMessage();
			}
		    }
		    logger.info (errorMess);
		}
		
		if (stateMap==null) {
		    String em="Unexpected error",errorMess="Something bad happened !";
		    logger.info ("FMlog "+new Date()+"--> "+myname+" trying to recover from app.execute exception");
		    int ntry=0;
		    boolean done=true;
		    while (ntry<10) {
			ntry++;
			try {
			    Thread.sleep(5000);
			} catch (InterruptedException e){
			    e.printStackTrace();
			    throw new  UserActionException("Thread sleep failed while waiting 5 sec");
			}
			
			Iterator it=appList.iterator();
			done=true;
			XdaqApplication myapp = null;
			while (it.hasNext()) {
			    myapp =(XdaqApplication) it.next();
			    if (!myapp.getState().equals(targetState)) {
				done=false;
				errorMess = "FMlog "+new Date()+"--> "+myname+" wrong state for "+myapp.getName()+": "+myapp.getState()+" instead of "+targetState;
				logger.info (errorMess);
				em = "Wrong state for "+myapp.getName()+": "+myapp.getState()+" instead of "+targetState;
			    }
			}
			if (done) break;
		    }
                    if (done)     logger.info("FMlog "+new Date()+"--> "+myname+" all states are fine !");
		    else {
			logger.info("FMlog "+new Date()+"--> "+myname+" failed to recover!");
			logger.error(errorMess);
			showError (em);
			throw new UserActionException(errorMess);
			
		    }
		}
		else {

	       	State returnedState = null;
		/*
		try {
		    Thread.sleep(sleeptime*1000);
		} catch (InterruptedException e){
		    e.printStackTrace();
		    throw new  UserActionException("Thread sleep failed while waiting "+sleeptime+" sec");
		}
		*/
		sleeptime=10;
                int ntry=0;
		int nmax=5;
		if(functionManager.getName().equals("FecStateMachine")) nmax=25;
		if(functionManager.getName().equals("FedStateMachine")) nmax=25;
		if(functionManager.getName().equals("DQMStateMachine")) nmax=25;
		String errorMess="Error message";
		String em ="Timeout";
	       	State returnedSummaryState = app.compareAllStates();
	       	if (!returnedSummaryState.equals(targetState)) {
                    while (ntry++ < nmax) {
			hasFailed=false;			
			isFine=true;

			if (execCrashed()) {
                            errorMess = "FMMlog "+new Date()+"--> "+myname+" Crash !!! ";
			    hasFailed=true;
			    isFine=false;
			    em = "Crash !";
                            break;
			}


			errorMess = "FMlog "+new Date()+"--> "+myname+" send " + command + " and expected a return state "
			    + targetState + " Following applications failed \n";
			Set appSet = stateMap.keySet();
			appIterator = appSet.iterator();
                        logger.info ("FMlog "+new Date()+"--> "+myname+" before loop on apps");
			while(appIterator.hasNext()) {
			    application = (XdaqApplication) appIterator.next();
			    returnedState = (State)stateMap.get(application);	
                            appState = application.getState();
			    if(!returnedState.equals(targetState)) errorMess = errorMess +
								       "FMlog Application " + application.getName()
								       + " failed. State returned was "
								       + returnedState + " ("+appState+")\n";

			    if (!appState.equals(targetState)) {
				logger.info ("FMlog "+new Date()+"--> "+myname+" Application not fine "+appState);
				isFine=false;

				if (appState.equals(new State("Failed"))
				    || appState.equals(new State("failed"))) { 
				    logger.info ("FMlog "+new Date()+"--> "+myname+" Application returned Failed");
				    em = "Application went to Failed";
				    hasFailed=true; 
				}
			    }
			}
                        logger.info ("FMlog "+new Date()+"--> "+myname+" after loop on apps");
			if (isFine) break;

			if (hasFailed) {
			    logger.info ("FMlog "+new Date()+"--> "+myname+" Breaking out of waiting due to Failed");
			    break;
			}
                        logger.info ("FMlog "+new Date()+"--> "+myname+" sleeping "+sleeptime+" secs ("+ntry+" of "+nmax+")");
			try {
			    Thread.sleep(sleeptime*1000);
			} catch (InterruptedException e){
			    e.printStackTrace();
			    throw new  UserActionException("Thread sleep failed while waiting "+sleeptime+" sec");
			}
		    }
		    if (!isFine) {
		    logger.error(errorMess);
		    showError (em);
		    throw new UserActionException(errorMess);
		    }
		    else {
			logger.info(errorMess);
                        logger.info("FMlog "+new Date()+"--> "+myname+" all states are fine !");
		    }
		    
		}

	    }
	}
	private void sendCommandToChildFM(FunctionManager fmClient,
			Input command, State targetState) throws UserActionException {
		State returnedState = null;
		if(fmClient == null) return;

		try {

			returnedState = fmClient.execute(command);
		} catch (Exception e) {
			String errMess = "FMlog TransitionActions: " + command.toString()
					+ "send to " + fmClient.getClass().getName() + " failed. ";
			logger.error(errMess + e.getMessage());
			throw new UserActionException(errMess, e);
		}

		if (!(returnedState.getStateString().equals(targetState
				.getStateString()))) {
			String errMess = "FMlog TransitionActions: " + command.toString()
					+ " send to " + fmClient.getResource().getName()
					+ " failed. \n FMlog State requested was "
					+ targetState.getStateString() + " and returned was "
					+ returnedState.getStateString();
			logger.error(errMess);
			throw new UserActionException(errMess);
		}
       
	
	}

	public void setErrorAction() throws UserActionException {
		logger.info("RCMS: TransitionActions setError");
	}

    /*
    public boolean execCrashed()  {
	List listExecutive = qualifiedGroup
	    .seekQualifiedResourcesOfType(new XdaqExecutive());
	XdaqExecutive ex = null;
        State exState = null;
        boolean crashed = false;
	Iterator it = listExecutive.iterator();
                while (it.hasNext()) {
			ex = (XdaqExecutive)it.next();
			exState = ex.getState();
			    if (!exState.equals(States.ENABLED)){
				logger.info ("FMMlog "+new Date()+" found a executive not Enabled: "+ex.getName()+" "+exState);
				crashed = true;
			    }
			    else logger.info ("FMMlog "+new Date()+" "+ex.getName()+" "+exState);
		}
		return crashed;
    }
*/

    public boolean execCrashed()  {
	List listExecutive = qualifiedGroup
	    .seekQualifiedResourcesOfType(new XdaqExecutive());
	XdaqExecutive ex = null;
        State exState = null;
        boolean crashed = false;
	Iterator it = listExecutive.iterator();
                while (it.hasNext()) {
			ex = (XdaqExecutive)it.next();
                        if (!ex.isAlive()) {
				logger.error ("FMMlog "+new Date()+"--> "+myname+" found a executive not alive: "+ex.getName()+" "+exState);
				crashed = true;
			    }
			    else logger.info ("FMMlog "+new Date()+"--> "+myname+" "+ex.getName()+" "+exState);
		}
		return crashed;
    }

    private void writeRunInfo (String a, String b)
    {
	//	if (runInfo == null) return;
	try {
	runInfo.publishRunInfo(a,b);
	} catch (RunInfoException e ) {
	    logger.error ("Error writing into RunInfo ",e);
	}
    }

    private void showError (String t) 
    {

	functionManager.getParameterSet().put(new FunctionManagerParameter<StringT>(Parameters.ERROR ,new StringT(t)));
    }

    private void passRunNumber () 
    {
		String runNumber = ((StringT)functionManager.getParameterSet().get(Parameters.RUN_NUMBER).getValue()).getString();
		String runType = ((StringT)functionManager.getParameterSet().get(Parameters.RUN_TYPE).getValue()).getString();
//we pass the run number to the TrackerSupervisor
		if ( !xdaqTrackerSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunFromRCMS");
			    xdaqParameter.setValue("RunFromRCMS",runNumber);
			    xdaqParameter.send();
			    xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunTypeName");
			    xdaqParameter.setValue("RunTypeName",runType);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number/Type in TrackerSupervisor",e);
			}
		    }
		}
		logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> TrackerSupervisor");
//we pass the run number to the GenericTCDSSupervisor
		if ( !xdaqGenericTCDSSupervisor.isEmpty() ) {
                    List tSupList= xdaqGenericTCDSSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunNumber");
			    xdaqParameter.setValue("RunNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in GenericTCDSSupervisor",e);
			}
		    }
		}
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> GenericTCDSSupervisor");
		if ( !xdaqTrackerLTCSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerLTCSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunTypeName");
			    xdaqParameter.setValue("RunTypeName",runType);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in TkLTCSupervisor",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunType --> TkLTCSupervisor");
		}
		if ( !xdaqTrackerTTCciSupervisor.isEmpty() ) {
                    List tSupList= xdaqTrackerTTCciSupervisor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunTypeName");
			    xdaqParameter.setValue("RunTypeName",runType);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in TkTTCciSupervisor",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunType --> TkTTCciSupervisor");
		}
//we pass the run number to the RootAnalyzer
		if ( !xdaqRootAnalyzer.isEmpty() ) {
                    List tSupList= xdaqRootAnalyzer.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunFromRCMS");
			    xdaqParameter.setValue("RunFromRCMS",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in RootAnalyzer",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> RootAnalyzer");
		}
		
//we pass the run number to the GlobalErrorDispatcher
		if ( !xdaqGlobalErrorDispatcher.isEmpty() ) {
                    List tSupList= xdaqGlobalErrorDispatcher.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("RunFromRCMS");
			    xdaqParameter.setValue("RunFromRCMS",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in GlobalErrorDispatcher",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> GlobalErrorDispatcher");
		}
//we pass the run number to the FilterUnitFramework
		if ( !xdaqFilterUnitFramework.isEmpty() ) {
                    List tSupList= xdaqFilterUnitFramework.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in FilterUnitFramework",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> FilterUnitFramework");
		}
//we pass the run number to the xdaqFUEventProcessor
		if ( !xdaqFUEventProcessor.isEmpty() ) {
                    List tSupList= xdaqFUEventProcessor.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in xdaqFUEventProcessor",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> xdaqFUEventProcessor");
		}
//we pass the run number to the testStorageManager
		if ( !xdaqtestStorageManager.isEmpty() ) {
                    List tSupList= xdaqtestStorageManager.getApplications();
		    Iterator tSup = tSupList.iterator();
                    while (tSup.hasNext()) {
			XdaqApplication t = (XdaqApplication)tSup.next();
			try {
			    XDAQParameter xdaqParameter = t.getXDAQParameter();
			    xdaqParameter.select("runNumber");
			    xdaqParameter.setValue("runNumber",runNumber);
			    xdaqParameter.send();
			} catch (Exception e) {
			    logger.error ("Error setting Run Number in testStorageManager",e);
			}
		    }
		    logger.info ("FMlog "+new Date()+"--> "+myname+" after RunNumber --> testStorageManager");
		}
		
    }
    private void buildFedMask()
    {
	Boolean fedids[]= new Boolean[500];
	String fedmask="";
	Arrays.fill(fedids,Boolean.FALSE);
	if (!xdaqFed9USupervisor.isEmpty()) {
	    List tSupList= xdaqFed9USupervisor.getApplications();
	    Iterator tSup = tSupList.iterator();
	    while (tSup.hasNext()) {
		XdaqApplication t = (XdaqApplication)tSup.next();
		try {
		    XDAQParameter xdaqParameter = t.getXDAQParameter();
		    Integer id = new Integer(xdaqParameter.getValue("FedID"));
		    fedids[id]=Boolean.TRUE;
		} catch (Exception e) {
		    logger.error ("Error setting Run Number/Type in Fed(USupervisor",e);
		}
	    }
	    
	    for (int i=0; i<500; i++) 
		if (fedids[i]) {
		    fedmask += i;
		    fedmask += "&3%";
		}
	    functionManager.getParameterSet().put(new FunctionManagerParameter<StringT>(Parameters.FED_MASK ,new StringT(fedmask)));
	    
	}
    }
}
