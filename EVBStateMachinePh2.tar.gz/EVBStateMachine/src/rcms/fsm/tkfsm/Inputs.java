package rcms.fsm.tkfsm;

import rcms.statemachine.definition.Input;

/**
 * @author Samim Erhan
 * 
 * Defines the Inputs (Commands) of an example detector Function Manager State
 * Machine
 */
public class Inputs {
	public static final Input INITIALIZE = new Input( "Initialize" );
	public static final Input PREPARE = new Input( "Prepare" );
	public static final Input INITIALISE = new Input( "Initialise" );
	public static final Input CONFIGURE = new Input("Configure");
	public static final Input TCONFIGURE = new Input("configure");
	public static final Input CONFIGUREDCU = new Input("ConfigureDcu");
	public static final Input PRECONFIGURE = new Input("PreConfigure");
	public static final Input HALT = new Input("Halt");
	public static final Input HALTDCU = new Input("HaltDcu");
        public static final Input PREHALT = new Input("PreHalt");
	public static final Input PRESTOP = new Input("PreStop");
	public static final Input ENABLE = new Input("Enable");
	public static final Input TENABLE = new Input("enable");
	public static final Input RESET = new Input("Reset");
	public static final Input TRESET = new Input("reset");
	public static final Input COLDRESET = new Input("ColdReset");
	public static final Input STOP = new Input("Stop");
	public static final Input RESTART =   new Input("Restart");
    //public static final Input REFRESHSTATE = new Input("CheckState");
        public static final Input DESTROY =  new Input("Destroy");
	public static final Input SETERROR = new Input("SetError");
}
