package rcms.fsm.tkfsm;

import org.apache.log4j.Logger;

import rcms.statemachine.StateChangedEvent;
import rcms.statemachine.StateChangedListener;

/**
 * @author Samim Erhan
 * 
 * State Changed Action of n example detector Function Manager
 *  
 */
public class StateChangedAction implements StateChangedListener {

	static Logger logger = Logger.getLogger(StateChangedAction.class);

	// StateChangedListener implementation
	public void stateChangedOccurred(StateChangedEvent evt) {

		StateMachine stateMachine = (StateMachine) evt.getSource();
		logger.info("Old State is " + stateMachine.getPreviousState()
				+ "; New State is " + stateMachine.getState());
	}

}
